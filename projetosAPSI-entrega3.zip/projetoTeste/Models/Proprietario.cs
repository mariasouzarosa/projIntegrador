﻿using System;
using System.Collections.Generic;

namespace projetoTeste.Models
{
    public partial class Proprietario
    {
        public string CpfProp { get; set; }
        public string Nome { get; set; }
        public string EstadoCivil { get; set; }
        public string Profissao { get; set; }
        public string Telefone { get; set; }
    }
}
