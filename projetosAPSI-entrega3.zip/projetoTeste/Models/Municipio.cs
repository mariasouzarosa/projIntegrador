﻿using System;
using System.Collections.Generic;

namespace projetoTeste.Models
{
    public partial class Municipio
    {
        public int CodMuni { get; set; }
        public string Nome { get; set; }
        public string Populacao { get; set; }
        public string Estado { get; set; }
    }
}
